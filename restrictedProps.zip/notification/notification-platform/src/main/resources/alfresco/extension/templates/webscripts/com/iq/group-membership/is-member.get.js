function main() {
    var groupName = args["groupname"];
    var isMember = false;
    logger.debug("groupName = " + groupName);
    var group = groups.getGroup(groupName);
    if (null == group) {
        model["isMember"] = isMember;
        return;
    }
    var allUsers = group.allUsers;
    logger.debug("Group '" + groupName + "' with size " + allUsers.length);
    isMember = allUsers.some(user => user.userName.equals(person.properties.userName));
    logger.debug("isMember? " + isMember);
    model["isMember"] = isMember;
}
main();