package com.inqool.alfresco.access.temp_access.job;

import org.alfresco.error.AlfrescoRuntimeException;
import org.alfresco.repo.security.authentication.AuthenticationUtil;
import org.alfresco.schedule.AbstractScheduledLockedJob;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

@DisallowConcurrentExecution
public class TempAccessRemovalScheduledJob extends AbstractScheduledLockedJob {

    @Override
    public void executeJob(JobExecutionContext jobContext) throws JobExecutionException {
        JobDataMap jobData = jobContext.getJobDetail().getJobDataMap();

        // Extract the Job executer to use
        Object executerObj = jobData.get("jobExecuter");
        if (executerObj == null || !(executerObj instanceof TempAccessRemovalExecuter)) {
            throw new AlfrescoRuntimeException("TempAccessRemovalScheduledJob data must contain valid 'Executer' reference");
        }

        final TempAccessRemovalExecuter jobExecuter = (TempAccessRemovalExecuter) executerObj;

        // Execute job as system user who has access everywhere
        AuthenticationUtil.runAs(() -> {
            jobExecuter.execute();
            return null;
        }, AuthenticationUtil.getSystemUserName());
    }
}
