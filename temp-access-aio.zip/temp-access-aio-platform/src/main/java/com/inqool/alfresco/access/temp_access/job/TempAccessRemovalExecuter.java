package com.inqool.alfresco.access.temp_access.job;

import com.inqool.alfresco.access.temp_access.model.TempAccessModel;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.repository.StoreRef;
import org.alfresco.service.cmr.search.ResultSet;
import org.alfresco.service.cmr.search.SearchService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.PermissionService;
import org.quartz.DisallowConcurrentExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.invoke.MethodHandles;
import java.util.List;

import static org.alfresco.service.cmr.repository.datatype.DefaultTypeConverter.INSTANCE;

@DisallowConcurrentExecution
public class TempAccessRemovalExecuter {
    private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
    public static final String QUERY_DUE_DATE_IN_PAST = "ASPECT:\"inqool:tempAccess\" and inqool:dueDate:[MIN TO TODAY]";
    private NodeService nodeService;
    private AuthorityService authorityService;
    private PermissionService permissionService;
    private SearchService searchService;

    public void execute() {
        LOGGER.debug("Init from TempAccessRemovalExecuter");
        // Find all nodes where dueDate < NOW
        final ResultSet rs = searchService.query(StoreRef.STORE_REF_WORKSPACE_SPACESSTORE, SearchService.LANGUAGE_FTS_ALFRESCO, QUERY_DUE_DATE_IN_PAST);
        if (rs.length() < 1) {
            LOGGER.debug("Nothing to be deleted");
            return;
        }

        final List<NodeRef> nodeRefs = rs.getNodeRefs();
        LOGGER.debug("Query {} found {} results", QUERY_DUE_DATE_IN_PAST, nodeRefs.size());
        for (NodeRef node : nodeRefs) {
            if (nodeService.exists(node)) {
                // Find user
                final String user = INSTANCE.convert(String.class, nodeService.getProperty(node, TempAccessModel.PROP_TEMP_ACCESS_USER));
                if (!authorityService.authorityExists(user)) {
                    LOGGER.debug("User {} does NOT exist", user);
                    return;
                }
                // Let's remove user
                permissionService.clearPermission(node, user);
                // Remove aspect
                nodeService.removeAspect(node, TempAccessModel.ASPECT_TEMP_ACCESS);
                LOGGER.debug("User {} was removed from {}", user, node);
            }
        }
    }

    public void setNodeService(NodeService nodeService) {
        this.nodeService = nodeService;
    }

    public void setAuthorityService(AuthorityService authorityService) {
        this.authorityService = authorityService;
    }

    public void setPermissionService(PermissionService permissionService) {
        this.permissionService = permissionService;
    }

    public void setSearchService(SearchService searchService) {
        this.searchService = searchService;
    }
}
