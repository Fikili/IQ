package com.inqool.alfresco.access.temp_access.model;

import org.alfresco.service.namespace.QName;

public interface TempAccessModel {
    public static final String TEMP_ACCESS_MODEL_URI = "http://www.inqool.cz/model/content/1.0";

    // ASPECTS
    public static final QName ASPECT_TEMP_ACCESS = QName.createQName(TEMP_ACCESS_MODEL_URI, "tempAccess");

    // PROPS
    public static final QName PROP_TEMP_ACCESS_USER = QName.createQName(TEMP_ACCESS_MODEL_URI, "tempUser");
    public static final QName PROP_TEMP_ACCESS_DUE_DATE = QName.createQName(TEMP_ACCESS_MODEL_URI, "dueDate");
}
