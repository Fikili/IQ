package com.inqool.alfresco.access.temp_access;

import com.inqool.alfresco.access.temp_access.model.TempAccessModel;
import org.alfresco.repo.action.ParameterDefinitionImpl;
import org.alfresco.repo.action.executer.ActionExecuterAbstractBase;
import org.alfresco.service.cmr.action.Action;
import org.alfresco.service.cmr.action.ParameterDefinition;
import org.alfresco.service.cmr.dictionary.DataTypeDefinition;
import org.alfresco.service.cmr.repository.NodeRef;
import org.alfresco.service.cmr.repository.NodeService;
import org.alfresco.service.cmr.security.AuthorityService;
import org.alfresco.service.cmr.security.PermissionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.invoke.MethodHandles;
import java.util.List;

public class TempAccessAction extends ActionExecuterAbstractBase {
    private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());
    private NodeService nodeService;
    private AuthorityService authorityService;
    private PermissionService permissionService;

    public static final String PARAM_TEMP_ACCESS_DUE_DATE = "dueDate";
    public static final String PARAM_TEMP_ACCESS_USER = "user";

    @Override
    protected void executeImpl(Action action, NodeRef actionedUponNodeRef) {
        LOGGER.debug("Init TempAccessAction");
        if (nodeService.exists(actionedUponNodeRef)) {
            // Get the email properties entered via Share Form
            final String dueDate = (String) action.getParameterValue(PARAM_TEMP_ACCESS_DUE_DATE);
            final String user = (String) action.getParameterValue(PARAM_TEMP_ACCESS_USER);
            LOGGER.debug("dueDate = {} | user = {}", dueDate, user);
            if (!authorityService.authorityExists(user)) {
                LOGGER.debug("User does NOT exist -> Let's skip other tasks");
                return;
            }

            // Set aspect + props
            nodeService.setProperty(actionedUponNodeRef, TempAccessModel.PROP_TEMP_ACCESS_USER, user);
            nodeService.setProperty(actionedUponNodeRef, TempAccessModel.PROP_TEMP_ACCESS_DUE_DATE, dueDate);
            // TODO: In case we need more users -> Let's use collection with one property in combination user_dueDate
            // Set permissions now -> Alfresco job will remove that later once dueDate is reached
            // TODO: Currently, FullControl is granted -> Change that to proper permissions
            permissionService.setPermission(actionedUponNodeRef, user, PermissionService.FULL_CONTROL, true);
            LOGGER.debug("Permissions were set for {}", user);
        }
    }

    @Override
    protected void addParameterDefinitions(List<ParameterDefinition> paramList) {
        for (String s : new String[]{PARAM_TEMP_ACCESS_DUE_DATE, PARAM_TEMP_ACCESS_USER}) {
            paramList.add(new ParameterDefinitionImpl(s, DataTypeDefinition.TEXT, true, getParamDisplayLabel(s)));
        }
    }

    public void setNodeService(NodeService nodeService) {
        this.nodeService = nodeService;
    }

    public void setAuthorityService(AuthorityService authorityService) {
        this.authorityService = authorityService;
    }

    public void setPermissionService(PermissionService permissionService) {
        this.permissionService = permissionService;
    }
}
